Orbit Labs logo pack. Primary and monochrome marks.
